package de.htwberlin.learningcompanion.sensordata.processing;

/**
 * Created by Max on 2019-07-04.
 *
 * @author Max Oehme
 */
public enum ProcessorNames {
    ORENTATION, MOVEMENT, LIGHT, NOISE
}
