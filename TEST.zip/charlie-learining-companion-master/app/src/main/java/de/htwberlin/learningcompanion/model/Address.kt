package de.htwberlin.learningcompanion.model

data class Address(var display_name: String, var lat: Double, var lon: Double)